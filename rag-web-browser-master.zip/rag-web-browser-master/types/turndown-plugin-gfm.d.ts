declare module 'joplin-turndown-plugin-gfm';
